import Foundation

var num, num2: Double
func main(parametro: Array<String>){
    print("Esta es una calculadora")
    print("Ingrese el primer numero:")
    var num = Double(readLine()!)!
    print("Elija la operacion a realizar \t 1.Suma \t 2.Resta \t 3.Multiplicación \t 4. división:")
    var operadores = readLine()!
    print("Ingrese el segundo numero:")
    var num2 = Double(readLine()!)!

    
}


let operadores = 4
switch operadores {
case 1:
    func suma (num: double, num2:double){
        let sumando = num+num2
       print("El numero \(num) sumado con el \(num2) es igual a \(sumando) ")
        
    }

case 2:
   func resta (num:double, num2:double){
        let resta = num*num1
        print("El numero \(num) resta al numero  \(num1) es igual a \(resta) ")
    }
case 3:
     func multiplicacion (num: double, num2:double){
        let multiplicacion = num2*num3
        print("El numero \(num2) al ser multiplicado  \(num3) es igual a \(multiplicacion) ")
    }

case 4:
     func division (num:double, num2:double){
        let division = dividendo/divisor
        print("El numero \(dividendo) al ser dividido  \(divisor) es igual a \(division) ")
    }
    
default: Return nil
}

